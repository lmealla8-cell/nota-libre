# Nota Libre — proyecto Android

Este es un proyecto fuente nativo para abrir con Android Studio. Incluye un prototipo funcional de notas locales con guardado automático, carpetas, PIN opcional general, PIN por carpeta, búsqueda, modo oscuro y papelera con vencimiento a 30 días.

## Cómo abrir
1. Instala Android Studio en una computadora.
2. Descomprime el ZIP.
3. En Android Studio, elige **Open** y selecciona la carpeta `NotaLibre_Android`.
4. Acepta instalar el SDK Android 36 y deja que Gradle sincronice.
5. Ejecuta en un emulador o conecta un Android con depuración USB.

## Importante
- Esto es código fuente Android, no un APK/AAB firmado ni una publicación en Play Store.
- No he podido compilarlo en este entorno porque no hay Android SDK instalado.
- Antes de publicar: probar en varios dispositivos, completar política de privacidad/ficha de tienda, revisar seguridad, configurar firma y generar un Android App Bundle (.aab).
- La persistencia usa DataStore local y SHA-256 para comparar PINs, pero no cifra el contenido de las notas. No lo uses para información altamente sensible hasta implementar cifrado con claves protegidas por Android Keystore.
- Los recordatorios/notificaciones y sincronización/copia de seguridad todavía no están implementados.
- La papelera elimina notas vencidas al iniciar la app; una versión de producción debe agregar un trabajo periódico para que el borrado ocurra aun sin abrirla.
- El identificador de aplicación usado es `com.notlibre.app`; confirma que esté disponible antes de publicar.
