package com.notlibre.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.UUID

private val android.content.Context.dataStore by preferencesDataStore(name = "nota_libre_data")
private val STORE_KEY = stringPreferencesKey("app_data_v1")
private val Purple = Color(0xFF7252B8)
private val Pale = Color(0xFFF5F0FF)

data class Note(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val body: String = "",
    val folder: String = "General",
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)

data class AppData(
    val notes: List<Note> = emptyList(),
    val folderPins: Map<String, String> = emptyMap(),
    val appPinHash: String = "",
    val dark: Boolean = false,
    val accent: Long = 0xFF7252B8
)

private fun pinHash(pin: String): String =
    MessageDigest.getInstance("SHA-256").digest(pin.toByteArray()).joinToString("") { "%02x".format(it) }

private fun encode(data: AppData): String {
    val root = JSONObject()
    root.put("appPinHash", data.appPinHash)
    root.put("dark", data.dark)
    root.put("accent", data.accent)
    val notes = JSONArray()
    data.notes.forEach { n ->
        notes.put(JSONObject().put("id", n.id).put("title", n.title).put("body", n.body)
            .put("folder", n.folder).put("updatedAt", n.updatedAt).put("deletedAt", n.deletedAt ?: JSONObject.NULL))
    }
    root.put("notes", notes)
    val pins = JSONObject()
    data.folderPins.forEach { (k, v) -> pins.put(k, v) }
    root.put("folderPins", pins)
    return root.toString()
}

private fun decode(raw: String): AppData = try {
    val root = JSONObject(raw)
    val arr = root.optJSONArray("notes") ?: JSONArray()
    val notes = (0 until arr.length()).map { i ->
        val n = arr.getJSONObject(i)
        Note(n.optString("id"), n.optString("title"), n.optString("body"), n.optString("folder", "General"),
            n.optLong("updatedAt", System.currentTimeMillis()),
            if (n.isNull("deletedAt")) null else n.optLong("deletedAt"))
    }
    val pinsJson = root.optJSONObject("folderPins") ?: JSONObject()
    val pins = mutableMapOf<String, String>()
    pinsJson.keys().forEach { k -> pins[k] = pinsJson.optString(k) }
    AppData(notes, pins, root.optString("appPinHash"), root.optBoolean("dark"), root.optLong("accent", 0xFF7252B8))
} catch (_: Exception) { AppData() }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NotaLibreApp() }
    }
}

@Composable
fun NotaLibreApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var data by remember { mutableStateOf(AppData()) }
    var loaded by remember { mutableStateOf(false) }
    var selectedFolder by remember { mutableStateOf("General") }
    var selectedNoteId by remember { mutableStateOf<String?>(null) }
    var search by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    var showFolderDialog by remember { mutableStateOf(false) }
    var showPinDialog by remember { mutableStateOf<String?>(null) }
    var pinEntry by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf("") }
    var showAppLock by remember { mutableStateOf(false) }
    var appPinEntry by remember { mutableStateOf("") }
    var showTrash by remember { mutableStateOf(false) }
    var newFolder by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var pinTarget by remember { mutableStateOf("folder") }
    var accentHex by remember { mutableStateOf("#7252B8") }

    LaunchedEffect(Unit) {
        data = decode(context.dataStore.data.first()[STORE_KEY] ?: "")
        loaded = true
        showAppLock = data.appPinHash.isNotBlank()
        // Expire deleted notes after 30 days whenever the app starts.
        val cutoff = System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000
        data = data.copy(notes = data.notes.filterNot { it.deletedAt != null && it.deletedAt < cutoff })
    }
    LaunchedEffect(data, loaded) {
        if (loaded) context.dataStore.edit { it[STORE_KEY] = encode(data) }
    }

    val isDark = data.dark
    val scheme = if (isDark) darkColorScheme(primary = Purple) else lightColorScheme(primary = Purple, secondary = Color(0xFF9A83D6))
    MaterialTheme(colorScheme = scheme) {
        if (showAppLock) {
            Surface(Modifier.fillMaxSize()) {
                Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Nota Libre", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Purple)
                    Text("Ingresá tu PIN para continuar")
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(appPinEntry, { appPinEntry = it.filter(Char::isDigit).take(6) }, label = { Text("PIN") })
                    if (pinError.isNotBlank()) Text(pinError, color = MaterialTheme.colorScheme.error)
                    Button(onClick = {
                        if (pinHash(appPinEntry) == data.appPinHash) { showAppLock = false; appPinEntry = ""; pinError = "" }
                        else pinError = "PIN incorrecto"
                    }) { Text("Desbloquear") }
                }
            }
            return@MaterialTheme
        }

        val selectedNote = data.notes.firstOrNull { it.id == selectedNoteId && it.deletedAt == null }
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.weight(1f)) {
                        Text("Nota Libre", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Purple)
                        Text("Tus ideas, a tu manera", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick = { showSettings = true }) { Text("Ajustes") }
                }
                Spacer(Modifier.height(12.dp))
                if (selectedNote != null) {
                    TextButton(onClick = { selectedNoteId = null }) { Text("← Volver a notas") }
                    OutlinedTextField(
                        value = selectedNote.title,
                        onValueChange = { value -> data = data.copy(notes = data.notes.map { if (it.id == selectedNote.id) it.copy(title = value, updatedAt = System.currentTimeMillis()) else it }) },
                        label = { Text("Título") }, modifier = Modifier.fillMaxWidth(), singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = selectedNote.body,
                        onValueChange = { value -> data = data.copy(notes = data.notes.map { if (it.id == selectedNote.id) it.copy(body = value, updatedAt = System.currentTimeMillis()) else it }) },
                        label = { Text("Escribí tu nota…") }, modifier = Modifier.fillMaxWidth().weight(1f), minLines = 8
                    )
                    Spacer(Modifier.height(6.dp))
                    Text("Guardado automático ✓", color = Purple, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { data = data.copy(notes = data.notes.map { if (it.id == selectedNote.id) it.copy(deletedAt = System.currentTimeMillis()) else it }); selectedNoteId = null }) { Text("Mover a papelera") }
                        OutlinedButton(onClick = { showTrash = true }) { Text("Papelera") }
                    }
                } else if (showTrash) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Papelera", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        TextButton(onClick = { showTrash = false }) { Text("Volver") }
                    }
                    LazyColumn {
                        items(data.notes.filter { it.deletedAt != null }, key = { it.id }) { n ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(n.title.ifBlank { "Nota sin título" }, fontWeight = FontWeight.SemiBold)
                                    val daysLeft = (((n.deletedAt ?: 0L) + 30L*24*60*60*1000 - System.currentTimeMillis()).coerceAtLeast(0) / (24*60*60*1000)).toInt()
                                    Text("Se elimina en aproximadamente $daysLeft días", fontSize = 12.sp)
                                    Row {
                                        TextButton(onClick = { data = data.copy(notes = data.notes.map { if (it.id == n.id) it.copy(deletedAt = null) else it }) }) { Text("Restaurar") }
                                        TextButton(onClick = { data = data.copy(notes = data.notes.filterNot { it.id == n.id }) }) { Text("Eliminar definitivamente") }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    OutlinedTextField(search, { search = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Buscar notas") }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        FilterChip(selectedFolder == "General", { selectedFolder = "General" }, label = { Text("General") })
                        data.notes.map { it.folder }.distinct().filter { it != "General" }.forEach { folder ->
                            FilterChip(selectedFolder == folder, {
                                if (data.folderPins[folder].isNullOrBlank()) selectedFolder = folder
                                else { showPinDialog = folder; pinTarget = "open"; pinEntry = ""; pinError = "" }
                            }, label = { Text("🔒 $folder") })
                        }
                        TextButton(onClick = { showFolderDialog = true }) { Text("+ Carpeta") }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(onClick = {
                            val note = Note(folder = selectedFolder)
                            data = data.copy(notes = data.notes + note)
                            selectedNoteId = note.id
                        }, modifier = Modifier.weight(1f)) { Text("+ Nueva nota") }
                        OutlinedButton(onClick = { showTrash = true }) { Text("Papelera") }
                    }
                    LazyColumn(Modifier.weight(1f)) {
                        val visible = data.notes.filter { it.deletedAt == null && (it.folder == selectedFolder) &&
                            (search.isBlank() || it.title.contains(search, true) || it.body.contains(search, true)) }
                            .sortedByDescending { it.updatedAt }
                        items(visible, key = { it.id }) { n ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { selectedNoteId = n.id }, shape = RoundedCornerShape(14.dp)) {
                                Column(Modifier.padding(14.dp)) {
                                    Text(n.title.ifBlank { "Nota sin título" }, fontWeight = FontWeight.SemiBold)
                                    Text(n.body.ifBlank { "Sin contenido" }.take(100), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showFolderDialog) {
        AlertDialog(onDismissRequest = { showFolderDialog = false }, title = { Text("Nueva carpeta") },
            text = { Column { OutlinedTextField(newFolder, { newFolder = it }, label = { Text("Nombre") }); Spacer(Modifier.height(8.dp)); Text("PIN opcional (4 a 6 dígitos)"); OutlinedTextField(newPin, { newPin = it.filter(Char::isDigit).take(6) }, label = { Text("PIN") }) } },
            confirmButton = { TextButton(onClick = {
                val name = newFolder.trim()
                if (name.isNotEmpty()) {
                    if (newPin.isNotBlank() && newPin.length < 4) { pinError = "Usá al menos 4 dígitos" }
                    else {
                        if (newPin.isNotBlank()) data = data.copy(folderPins = data.folderPins + (name to pinHash(newPin)))
                        selectedFolder = name; newFolder = ""; newPin = ""; showFolderDialog = false
                    }
                }
            }) { Text("Crear") } },
            dismissButton = { TextButton(onClick = { showFolderDialog = false }) { Text("Cancelar") } })
    }

    if (showSettings) {
        AlertDialog(onDismissRequest = { showSettings = false }, title = { Text("Ajustes") },
            text = { Column {
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Modo oscuro", modifier = Modifier.weight(1f)); Switch(data.dark, { data = data.copy(dark = it) }) }
                Text("PIN general (opcional)", fontWeight = FontWeight.SemiBold)
                OutlinedTextField(newPin, { newPin = it.filter(Char::isDigit).take(6) }, label = { Text("PIN de 4 a 6 dígitos") })
                Row {
                    TextButton(onClick = { if (newPin.length >= 4) { data = data.copy(appPinHash = pinHash(newPin)); newPin = "" } }) { Text("Activar / cambiar") }
                    TextButton(onClick = { data = data.copy(appPinHash = ""); newPin = "" }) { Text("Quitar PIN") }
                }
                Text("Color de acento (hexadecimal)", fontWeight = FontWeight.SemiBold)
                OutlinedTextField(accentHex, { accentHex = it }, label = { Text("#7252B8") })
                TextButton(onClick = { try { data = data.copy(accent = android.graphics.Color.parseColor(accentHex).toLong()); showSettings = false } catch (_: Exception) {} }) { Text("Aplicar color") }
            } },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Cerrar") } })
    }

    if (showPinDialog != null) {
        AlertDialog(onDismissRequest = { showPinDialog = null }, title = { Text("Carpeta protegida") },
            text = { Column { Text("Ingresá el PIN de ${showPinDialog}"); OutlinedTextField(pinEntry, { pinEntry = it.filter(Char::isDigit).take(6) }, label = { Text("PIN") }); if (pinError.isNotBlank()) Text(pinError, color = MaterialTheme.colorScheme.error) } },
            confirmButton = { TextButton(onClick = {
                if (pinHash(pinEntry) == data.folderPins[showPinDialog]) { selectedFolder = showPinDialog!!; showPinDialog = null; pinEntry = ""; pinError = "" }
                else pinError = "PIN incorrecto"
            }) { Text("Desbloquear") } },
            dismissButton = { TextButton(onClick = { showPinDialog = null }) { Text("Cancelar") } })
    }
}
